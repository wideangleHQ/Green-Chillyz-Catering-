# Information Architecture & Sitemap

## Principle

Navigate by **occasion** ("I need catering for my wedding"), not by internal service taxonomy. Keep top-nav shallow; push depth into content blocks, not extra pages.

## Sitemap

```
Home
About Green Chillyz Catering
Catering Services (hub)
    ├── Wedding Catering
    ├── Reception Catering
    ├── Haldi & Mehendi
    ├── Corporate Catering
    ├── Birthday & Celebrations
    ├── Outdoor / Private Events
    └── Live Food Stations
Menus
    ├── Signature Menus
    ├── Regional Cuisine
    ├── International Cuisine
    └── Buffet / Packages
Gallery
Testimonials
FAQ
Contact / Get a Quote
```

## Page vs. section vs. future decision

| Item | Treatment | Rationale |
|---|---|---|
| Each event type (Wedding, Corporate, etc.) | Dedicated page | Distinct SEO keyword + distinct buyer intent |
| Live Food Stations | Homepage section + subsection under Menus | Sells experience, doesn't need standalone page at V1 |
| Regional/International Cuisine | Tabs/filters within Menus page | Avoids page-count bloat |
| Legacy/Awards/QR codes (catalog Sec. 5, 19, 23) | Content blocks within About/Contact | Not enough unique content for standalone pages |
| Booking Process | Section on Contact page | Supports the Quote CTA, not a destination itself |
| Blog | Future page (Phase 4) | Needs content pipeline not yet resourced |

## Navigation rules

- Primary nav: Home, Services, Menus, Gallery, About, Contact
- Get a Quote is a persistent header button, not buried in Contact
- WhatsApp is a persistent floating action, not nav-dependent
- No login/account nav item (out of scope, Sec. 11)
