# Overview & Business Understanding

## What this project is

A **premium catering brand website + digital catalogue + lead-generation platform** for Green Chillyz Catering. It is **not** an ecommerce checkout site, and it is **not** the GreenChillyz QSR/restaurant website.

## Business snapshot

| Field | Value | Status |
|---|---|---|
| Legal entity | Green Chillyz Catering & Foods Pvt Ltd | Confirmed (audit) |
| Website | www.greenchillyzcatering.com | Confirmed |
| Address | 2132/5140, Lewis Road, BJB Nagar, Bhubaneswar, Odisha 751014 | Confirmed (audit) |
| Phone | +91-9090022220, +91-9778011110 | Confirmed (audit) — verify before publishing as WhatsApp |
| Email | info@greenchillyzcatering.com | Confirmed |
| Founding year | 2009 (audit) vs. 1999 "Legacy" (catalog) | **Conflict — see Sec. 11** |
| Experience claim | "15+ years" | Proposed, pending confirmation |

## Business relationship

```
GreenChillyz Group
    ├── GreenChillyz QSR / Restaurant (12 outlets, loyalty, games, coins, franchise)
    ├── YellowChillyz
    ├── GoldenChillyz
    └── Green Chillyz Catering  ← THIS PROJECT
```

Catering has its **own** positioning, journey, IA, and conversion strategy. Restaurant ratings/menus/loyalty are explicitly **out of scope** (Sec. 11).

## Why catering is a different product than a restaurant site

| Restaurant | Catering |
|---|---|
| Individual dish + price | Package built around event, guest count, service |
| Instant order/checkout | Enquiry → human quote → negotiation |
| Repeat, low-trust transaction | High-value, high-trust, infrequent purchase |
| Menu is the product | Menu + experience + hygiene + photography + testimonials is the product |

Trust, food photography, event photography, and clear menu/package framing matter disproportionately because the buyer is committing a large sum, sight-unseen, for an irreversible date (a wedding, a launch event). Hygiene and FSSAI-type signals matter because food safety for hundreds of guests is a real risk the buyer is transferring to the caterer.

## Core business objective

> **Generate qualified catering enquiries and convert them into booked events.**

## Secondary goals

- Establish premium positioning distinct from the QSR brand
- Build trust via real event photography, hygiene info, testimonials
- Showcase menus/packages without publishing unconfirmed pricing
- Make WhatsApp/phone contact effortless
- Improve local SEO (Bhubaneswar + event-type keywords)
- Support the sales team's quotation workflow, not replace it

## Core funnel

```
Discover → Understand services → Explore event type → Explore menu →
View gallery → Build trust (testimonials/hygiene) → Get a Quote →
Submit enquiry → WhatsApp/phone follow-up → Quotation → Booking → Event
```
