# Design, UX, Accessibility & Performance

## Design direction

> Premium Catering Brand + Hospitality + Modern Digital Experience

Avoid reading as: a generic restaurant site, a cheap local-business template, a food-delivery app, an ecommerce grocery store, or an overly corporate B2B site.

Favor: large food/event photography, elegant typography, strong whitespace, clear visual hierarchy, subtle motion, strong CTA placement, mobile-first layout. Colors/typography must stay consistent with the existing Green Chillyz brand — do not choose a new palette without documenting rationale and client sign-off.

## Responsive behaviour

| Element | Desktop | Mobile |
|---|---|---|
| Header/nav | Full nav visible | Hamburger, Get-a-Quote button always visible |
| Hero | Side-by-side text/image | Stacked, text over image with gradient overlay |
| Service/event cards | Grid (3–4 col) | 1-col stack, swipeable optional |
| Gallery | Masonry/grid | Swipeable single-column, lightbox |
| Menus | Tabbed multi-column | Accordion/tabs, one section open at a time |
| Forms | Multi-column | Single column, large touch targets |
| WhatsApp button | Corner floating | Corner floating, above thumb-reach zone, never covering CTA |
| Footer | Multi-column | Accordion sections |

Mobile is the priority surface — the audit flags mobile experience as a major current weakness.

## Accessibility

Semantic HTML, full keyboard navigation, visible focus states, WCAG-AA contrast, alt text on every image, labeled form fields with inline error messaging, touch targets ≥44px, respect `prefers-reduced-motion`, logical heading hierarchy (single H1 per page), screen-reader-tested primary flows (nav, form submission).

## Performance

Compressed images in modern formats (WebP/AVIF), responsive `srcset`, lazy loading below the fold, font-loading optimization, critical CSS for above-the-fold content, CDN for static assets, browser caching, Core Web Vitals (LCP/CLS/INP) tracked post-launch. Because this site is photography-heavy, image strategy is a first-class technical requirement, not an afterthought.
