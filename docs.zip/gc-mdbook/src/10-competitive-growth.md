# Competitive Positioning & Growth Opportunities

## Competitors (per audit — cited, not invented)

| Competitor | Cited strength | Cited weakness |
|---|---|---|
| Glorious Caterers | Premium branding, on-site testimonials | Limited online presence, single location |
| Das Catering Services | Lower price point, WedMeGood profile | Capacity capped ~10,000, fewer locations |
| Wow Tasty Catering | 4.9/5 rating (210 reviews) on JustDial | Single location |

## Proposed differentiation (pending client approval — not confirmed positioning)

Experience/longevity, professional presentation, event-scale capability, brand trust from the wider GreenChillyz name, menu variety, stronger digital experience than competitors currently show.

## Growth opportunities (marked as growth ideas, not V1 website requirements)

Google Ads on catering-intent keywords; WedMeGood/WeddingWire vendor profiles; premium menu tiers; cross-selling with decor/photography/DJ vendors; email nurture sequences; corporate repeat contracts; referral program; WhatsApp automation; CRM adoption; structured review generation; blog/content marketing.

## Content/blog funnel (future)

`SEO Article → Service Page → Gallery → Testimonial → Get Quote`

Topics: wedding catering tips (Bhubaneswar-specific), outdoor event menu ideas, guest-count planning, buffet planning, live-station ideas.
