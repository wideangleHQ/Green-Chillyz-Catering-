# Scope, Conflicts & Open Questions

## Terminology used throughout this handbook

| Label | Meaning |
|---|---|
| Confirmed fact | Explicitly stated in a supplied source |
| Proposed requirement | Something this project should implement |
| Recommendation | Suggested by the audit/consultant |
| Assumption | Working assumption, not yet confirmed |
| Open question | Must be answered by the client |
| Future opportunity | Intentionally out of initial scope |

## Source conflicts requiring client confirmation

| Topic | Source A (Audit) | Source B (Catalog) | Status |
|---|---|---|---|
| Founding year | 2009 | "Legacy Since 1999" | **Client confirmation required** |
| Experience claim | 15+ years | Legacy since 1999 (implies 25+ years) | **Client confirmation required** |
| Catering locations | Multiple (4 referenced restaurant locations) | Not specified | Must distinguish catering service area from QSR outlet count (12, per Group report) |
| Pricing | ₹300–450 referenced | ₹300/450/600/800 recommended packages | **Not confirmed** — do not publish |
| Event count | "500+ events" suggested as badge | Not confirmed anywhere | **Do not publish until verified** |
| FSSAI | Recommended as trust signal | Actual license not supplied | **Client must provide details** |

## In scope

Premium catering website; catering service pages; event-type pages; menus/packages (enquiry-based per Sec. 05); gallery; testimonials; FAQ; contact; quote enquiry system; WhatsApp integration; SEO foundation; responsive UI; analytics.

## Out of scope (unless explicitly approved as a future integration)

Online payment / ecommerce checkout; full booking calendar; automated quotation engine; customer login/dashboard; CRM (V1); AI chatbot; QSR restaurant ordering; restaurant loyalty coins/games; franchise dashboards; the 12-outlet restaurant structure. These belong to the broader GreenChillyz Group product, not this catering site.

## Known gaps (content/business inputs still needed)

- Final founding year and experience claim
- Confirmed catering service areas (vs. restaurant outlet list)
- Confirmed pricing/package structure
- Confirmed event count (if any figure is to be published)
- FSSAI license details
- Any actual awards/certifications
- Real, permission-cleared testimonials (catering-specific, not restaurant ratings)
- Current event photography (2024–2026, not 2022-era assets)
- Final menu/package documents
- Confirmed WhatsApp Business number
- Confirmed social media handles
- Confirmed booking/advance-payment process

## Open questions

**Business:** Official founding year? Publishable experience claim? Actual completed-event count? Which areas/cities are served? Maximum guest capacity supported?

**Menus:** Which menus are current? Is pricing to be public, "starting from," or enquiry-only? Fixed or customizable packages? Veg/non-veg split? Actual regional/international cuisines offered?

**Events:** Which event categories launch in V1?

**Trust:** FSSAI status? Awards? Certifications? Client logos usable? Testimonials available?

**Operations:** Who receives enquiries? Expected response time? Who prepares quotes? Existing CRM in use?

**Content:** Who supplies photography? Who approves copy? Who owns future content updates?
