# Decision Log

Newest at the bottom. Format:

```markdown
## YYYY-MM-DD Short title
**Decision.** What was decided.
**Why.** Why.
**Instead of.** Rejected alternative.
**Costs.** What this makes harder later.
```

## 2026-09-09 Catering site is lead-generation-first, not ecommerce

**Decision.** The primary conversion is a quote enquiry, not a checkout.
**Why.** Catering is a high-value, negotiated, human-sales-driven purchase; forcing a cart/checkout model mismatches how the business actually sells.
**Instead of.** An ecommerce-style menu-and-cart flow.
**Costs.** No self-serve online purchase path; sales team remains the closing step.

## 2026-09-09 Catering brand is kept separate from restaurant/QSR messaging

**Decision.** Catering pages never reuse restaurant ratings, restaurant menus, or QSR loyalty content as trust proof.
**Why.** Buyers are evaluating an event caterer, not a quick-service diner; conflating the two undermines premium positioning.
**Instead of.** Sharing testimonials/ratings across both properties.
**Costs.** Catering-specific testimonials and photography must be collected independently.

## 2026-09-09 Unverified trust claims and pricing are not published

**Decision.** Founding year, event count, FSSAI details, and per-plate pricing stay off the live site until the client confirms them.
**Why.** The audit's figures are recommendations/estimates, not confirmed facts (Sec. 11); publishing them risks false claims.
**Instead of.** Shipping the audit's suggested badges/pricing as-is.
**Costs.** Some trust/pricing sections launch thinner than ideal until confirmations arrive.

## 2026-09-09 QSR features (games, coins, franchise, outlet dashboards) stay out of catering scope

**Decision.** These remain part of the broader GreenChillyz Group platform.
**Why.** They serve a different product and audience; importing them would blur positioning and inflate scope.
**Instead of.** A unified GreenChillyz Group super-app approach.
**Costs.** No shared login/rewards between the two properties unless a future integration is explicitly scoped.
