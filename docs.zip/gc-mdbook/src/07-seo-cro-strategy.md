# SEO & CRO Strategy

## SEO — homepage

Meta title/description, single clear H1, logical H2 hierarchy, internal links to service/menu/gallery pages, descriptive image alt text throughout. Target keyword theme: "Catering Bhubaneswar", "Premium Catering Odisha".

## SEO — service pages

Target keyword themes (not guaranteed rankings): Wedding Catering Bhubaneswar, Corporate Catering Bhubaneswar, Event Catering Bhubaneswar, Outdoor Catering Bhubaneswar, Birthday Catering Bhubaneswar.

## Local SEO

- Google Business Profile — separate/clarified from the restaurant locations, catering-specific category and photos
- NAP (name/address/phone) consistency across web
- Structured data (LocalBusiness / FoodEstablishment schema where applicable)
- Review generation aimed at catering clients, not restaurant diners

## Technical SEO

Canonical URLs, XML sitemap, robots.txt, structured data (Organization/Service), Open Graph tags, breadcrumbs, Core Web Vitals monitoring, compressed/responsive images.

## Content/blog opportunities (future, Phase 4)

Wedding catering tips in Bhubaneswar; outdoor event menu ideas; guest-count planning guides; buffet planning; live-station ideas. Funnel: `SEO Article → Service Page → Gallery → Testimonial → Get Quote`.

## CRO — what converts

Get a Quote CTA, WhatsApp, click-to-call, event-specific CTAs (not generic "Contact Us"), gallery, testimonials, trust signals, menu/package previews, FAQ, unambiguous next step on every page.

## CRO — patterns to avoid

- Generic "Contact Us" instead of "Get a Quote"
- Phone number buried in footer only
- Oversized form (more than the 6 fields in Sec. 06)
- No event type or guest count field
- No stated response-time expectation ("We reply within X hours")
- No catering-specific testimonials
- Restaurant-flavored messaging bleeding into catering pages
- Generic stock imagery instead of real events
