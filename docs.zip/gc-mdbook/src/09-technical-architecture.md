# Technical Architecture, Data Model & Admin

No specific stack, framework, hosting, or CMS is confirmed. If a repository already exists, inspect it before assuming anything below — this is a conceptual/technology-agnostic architecture until a stack decision is logged (Sec. 12).

## Conceptual layers

```
Presentation Layer → UI Components → Content/CMS → Enquiry API →
Lead Storage → Notifications → CRM / WhatsApp / Email (integrations)
```

## Conceptual data entities

| Entity | Purpose | Key fields (conceptual) | Notes |
|---|---|---|---|
| Customer | Person submitting an enquiry | name, phone, email | Not a login account (out of scope) |
| Enquiry | A quote request | event type, date, guest count, location, message, status | Drives lead lifecycle (Sec. 06) |
| Service | A catering service category | name, description, related menus | Wedding, Corporate, etc. |
| Menu / Package | Structured offering | cuisine, courses, tier | Pricing field marked confidential/unconfirmed until client sign-off |
| GalleryItem | A published photo | category, alt text, caption, image asset | Category maps to Sec. 05 list |
| Testimonial | Published review | name, event type, quote, moderation status | Moderated before publish |
| FAQ | Published Q&A | question, answer, category | — |
| ContactRequest | Generic contact (vs. structured enquiry) | name, phone/email, message | Simpler than Enquiry |
| LeadStatus | Enum tracking Enquiry state | see Sec. 06 lifecycle | — |

No specific database technology is assumed; document the actual choice as a decision (Sec. 12) once made.

## Admin/CMS requirements

| Content | V1 requirement | Future CMS capability |
|---|---|---|
| Services, event types | Editable | Full CRUD UI |
| Menus/packages | Editable | Full CRUD UI |
| Gallery | Uploadable, categorizable | Bulk upload, auto-compression |
| Testimonials | Add + moderate | Approval workflow |
| FAQs | Editable | — |
| Contact info | Editable | — |
| SEO metadata | Editable per page | — |
| Offers/promotions | Not required at V1 | Future |

Do not introduce a full admin dashboard unless justified by V1 content-update frequency — start with the minimum needed to keep content current without a developer.

## Analytics events

`page_view, service_view, menu_view, gallery_open, testimonial_view, quote_cta_click, quote_form_start, quote_form_submit, whatsapp_click, phone_click, email_click`

Funnel: `Visitors → Service Views → Quote CTA Clicks → Form Starts → Form Submissions → Qualified Leads → Quotes → Confirmed Events`

## Security & privacy

HTTPS everywhere, server-side form validation, spam/rate-limit protection, secure storage of lead PII (phone numbers especially), access control on who can view lead data internally, a privacy policy, and a cookie policy if analytics/marketing cookies are used. Do not claim legal compliance (DPDP, etc.) without actual verification.

## Integrations

| Tier | Integration |
|---|---|
| Core (required) | WhatsApp, Email, Phone |
| Recommended (near-term) | Google Business Profile, Analytics, Search Console |
| Future | CRM, social media auto-post, email marketing, automated follow-up |
