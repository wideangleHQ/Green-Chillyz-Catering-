# Content Model — Services, Menus, Gallery, Testimonials, Trust

## Catering services (from source docs — do not invent new ones)

| Service | Typical customer | Visitor wants to know | SEO keyword theme |
|---|---|---|---|
| Wedding Catering | Wedding client, planner | Capacity, menu range, live counters, styling | Wedding Catering Bhubaneswar |
| Reception Catering | Wedding client | Formal buffet/plated options | Reception Catering Bhubaneswar |
| Haldi & Mehendi | Wedding client | Casual/colorful presentation, smaller scale | Haldi Mehendi Catering |
| Corporate Catering | Corporate client | Reliability, professionalism, meal formats | Corporate Catering Bhubaneswar |
| Birthday Celebrations | Private client | Flexible packages, presentation | Birthday Catering Bhubaneswar |
| Private Events | Private client | Small/medium event support | Event Catering Bhubaneswar |
| Outdoor Catering | Any | Logistics, setup capability | Outdoor Catering Bhubaneswar |
| Live Food Stations | All | Experience/interaction, not just food | (supporting content, not primary keyword) |
| Buffet Catering | All | Styling, variety, service flow | — |

## Menus & packages

**Restaurant menu ≠ catering menu.** Catering menus are structured around event + guest count + service level, not à la carte pricing.

```
Package → Cuisine → Starters → Main Course → Rice/Breads → Desserts → Live Stations → Add-ons
```

**Pricing:** the audit's ₹300/450/600/800-per-plate figures are a **recommendation**, not confirmed current pricing. Do not publish as fact. Options to resolve (client decision required):

| Approach | Pros | Cons |
|---|---|---|
| Publish exact pricing | Max transparency, filters unqualified leads | Locks in price publicly, competitive exposure |
| Publish "starting from ₹X" | Transparency + flexibility | Still needs a real confirmed floor price |
| Enquiry-based only | Full flexibility, protects margin | Higher friction, may lose price-sensitive browsers |
| Downloadable package PDF (gated by form) | Transparency + captures a lead | Requires maintaining a PDF asset |

Recommended default until client confirms: **enquiry-based with a downloadable indicative package PDF**, gated behind the quote form.

## Live food stations

Sell the experience, not the dish list: station type, prep visible to guests, chef/service interaction, presentation, real event photos. This content lives primarily in the Gallery + a homepage section, not a standalone page (Sec. 03).

## Event gallery

Categories: Weddings, Receptions, Haldi, Mehendi, Corporate, Birthdays, Buffet setups, Live stations, Desserts, Service staff, Kitchen/prep, Table presentation.

Technical requirements: consistent aspect ratio per grid row, compressed/modern formats (WebP/AVIF), lazy loading below the fold, descriptive alt text (not generic "image1.jpg"), captions where useful, lightbox with swipe on mobile.

## Trust framework

| Element | Status |
|---|---|
| Years of experience | Proposed pending founding-year confirmation (Sec. 11) |
| "500+ events completed" | **Do not publish** — unverified, audit-suggested badge only |
| Real event photography | Required — must replace outdated 2022-era imagery |
| Testimonials (catering-specific) | Required — restaurant ratings are NOT valid catering trust proof |
| Hygiene/food-safety info | Required — generic hygiene copy until FSSAI confirmed |
| FSSAI license | **Do not publish** until client supplies actual license details |
| Awards | **Do not publish** until verified |
| Kitchen/process imagery | Recommended, pending supply |

## Testimonial system

Fields: customer name, event type, (optional) location, (optional) guest count, testimonial text, (optional) photo, (optional) date. All testimonials require manual moderation before publish. Never source testimonials from the restaurant/QSR business.
