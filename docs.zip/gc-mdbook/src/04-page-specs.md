# Page Specifications

Every page below follows this template: Purpose · Primary user · Business objective · SEO objective · Primary/secondary CTA · Sections · Mobile notes · Analytics events.

## Homepage

```
Header → Hero → Why Green Chillyz → Catering Services → Event Types →
Signature Menus → Live Food Stations → Trust/Experience → Event Gallery →
Testimonials → Hygiene & Quality → FAQ → Get a Quote → WhatsApp/Contact → Footer
```

| Section | Objective | CTA | Mobile behaviour |
|---|---|---|---|
| Hero | State identity + event categories in 3 seconds | Get a Quote (primary), Explore Catering (secondary), WhatsApp Us (optional) | Stack CTAs vertically, hero image behind gradient for text contrast |
| Why Green Chillyz | Establish credibility fast | — | 3-4 stat/trust cards, horizontal scroll on mobile |
| Catering Services | Route by service type | View service | Card grid → 1-col stack |
| Event Types | Route by occasion | View event type | Same as above |
| Signature Menus | Preview capability without full pricing | Explore Menus | Carousel |
| Live Food Stations | Sell the *experience* | View Gallery | Video/image carousel, lazy-loaded |
| Trust/Experience | Reduce risk perception | — | Icon row: years, hygiene, real photos |
| Event Gallery | Social proof via real work | View Full Gallery | Lightbox, swipe on mobile |
| Testimonials | Peer validation | — | Carousel, 1 visible at a time on mobile |
| Hygiene & Quality | De-risk the booking decision | — | Static content block |
| FAQ | Pre-empt objections before contact | — | Accordion |
| Get a Quote | Primary conversion | Submit | Sticky form or sticky button scrolling to form |
| Footer | Secondary nav + contact + social | Call / WhatsApp | Collapsed accordion sections |

**Hero messaging (proposed, not sourced):** "Premium Catering for Weddings, Celebrations & Corporate Events." Mark as draft copy pending client approval — must not read as vague brand poetry.

## Hero — must communicate

1. Identity (Green Chillyz Catering, distinct from the restaurant)
2. Service offered
3. Event categories served
4. Premium positioning
5. Primary CTA (Get a Quote)

## Catering Service pages (one per event type)

Purpose: convert occasion-specific intent. Primary user: persona matching that occasion (Sec. 2).

Sections: Description → Typical customer fit → What buyers want to know (capacity, style, timeline) → Suggested visual proof → Related menus → Testimonials filtered to this event type → CTA.

SEO keyword theme per page (targets, not guaranteed rankings): "Wedding Catering Bhubaneswar", "Corporate Catering Bhubaneswar", "Birthday Catering Bhubaneswar", "Outdoor Catering Bhubaneswar".

## Menus page

Sections: Signature Menus → Regional Cuisine → International Cuisine → Buffet/Package structure (Package → Cuisine → Starters → Mains → Rice/Breads → Desserts → Live Stations → Add-ons) → Pricing approach (see Sec. 05) → CTA to Quote.

## Gallery page

Category filters: Weddings, Receptions, Haldi, Mehendi, Corporate, Birthdays, Buffet setups, Live stations, Desserts, Staff/service, Kitchen/prep, Table presentation. Lightbox with lazy loading, descriptive alt text per image, captions optional.

## Testimonials page

Card per testimonial: name, event type, (optional) location/guest count, quote, (optional) photo/date. Moderation: manual approval before publish; no auto-publish of submitted testimonials.

## FAQ page

Content-sourced from real client questions (to be collected — Known Gaps, Sec. 11). Structure: accordion, grouped by Booking / Menus / Logistics / Pricing.

## Contact / Get a Quote page

Sections: Enquiry form (Sec. 06) → Phone CTA → WhatsApp CTA → Email → Map/service area → Business hours (pending confirmation) → Social links → Booking process summary → FAQ link.

Objective: **make contacting Green Chillyz effortless** — no page should require more than one action to reach a human.
