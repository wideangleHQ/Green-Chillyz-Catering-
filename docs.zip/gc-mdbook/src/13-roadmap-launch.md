# Roadmap, Requirement Traceability & Launch Checklist

## Roadmap

| Phase | Focus |
|---|---|
| 1 — Foundation | Discovery, content collection, IA, UI design, core pages |
| 2 — Conversion | Quote form, WhatsApp, contact, testimonials, trust sections |
| 3 — SEO & Performance | Metadata, structured data, image optimization, local SEO, Core Web Vitals |
| 4 — Growth | Blog, CRM, automated follow-up, deeper analytics, paid acquisition |

No dates are assigned — none are supported by source material.

## Requirement traceability

| Business need | Website requirement | Feature | Priority |
|---|---|---|---|
| Build trust | Proof of experience | Trust section | P0 |
| Generate leads | Easy enquiry | Quote form | P0 |
| Fast contact | Immediate conversation | WhatsApp CTA | P0 |
| Showcase capability | Real event proof | Gallery | P0 |
| Explain services | Occasion-based discovery | Service pages | P0 |
| Reduce risk perception | Hygiene/quality info | Trust content block | P0 |
| Improve SEO | Local + event-keyword intent | SEO structure | P1 |
| Improve conversion | Social proof | Testimonials | P1 |
| Support sales | Lead notification | Enquiry backend | P1 |
| Improve growth | Content acquisition | Blog | P2 |
| Vendor/partner reach | Marketplace presence | WedMeGood/WeddingWire profile | P2 |

## Launch checklist

**Business**
- [ ] Founding year confirmed
- [ ] Experience claim confirmed
- [ ] Contact numbers confirmed (incl. WhatsApp)
- [ ] Email confirmed
- [ ] Address/service area confirmed

**Content**
- [ ] Menus/packages approved
- [ ] Services approved
- [ ] Gallery supplied (current photography)
- [ ] Testimonials approved (catering-specific)
- [ ] FAQs approved
- [ ] All trust claims verified before publish

**Design**
- [ ] Desktop complete
- [ ] Mobile complete
- [ ] Tablet checked
- [ ] Accessibility checked

**Technical**
- [ ] HTTPS
- [ ] Forms tested (validation, success, error, spam protection)
- [ ] WhatsApp tested
- [ ] Analytics events firing
- [ ] SEO metadata in place
- [ ] Sitemap + robots.txt
- [ ] Structured data
- [ ] Performance/Core Web Vitals checked

**Conversion**
- [ ] Quote CTA visible on every page
- [ ] Form submits and shows success state
- [ ] Sales team confirmed receiving leads
- [ ] WhatsApp link works on mobile and desktop
- [ ] Phone number is tap-to-call on mobile
