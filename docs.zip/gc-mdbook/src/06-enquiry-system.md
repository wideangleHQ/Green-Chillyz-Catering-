# Enquiry System, WhatsApp & Booking

## Get-a-Quote form

```
Event Type → Event Date → Guest Count → Location → Contact Details → Requirements/Message → Submit
```

| Field | Required? | Notes |
|---|---|---|
| Name | Required | — |
| Phone | Required | Primary follow-up channel |
| Event Type | Required | Drives internal routing |
| Event Date | Required | Availability check |
| Guest Count | Required | Drives quote sizing |
| Location | Optional→Required for outdoor events | Conditional |
| Requirements/Message | Optional | Free text |

States to design: default, validation errors (inline, field-level), loading, success (with a lead ID / reference shown to user), duplicate-submission guard (debounce + idempotency key), spam protection (honeypot + rate limit, no intrusive CAPTCHA on first load).

On submit: create lead record → notify sales team (email/SMS/internal) → optional CRM push (future) → show WhatsApp fallback ("Prefer to chat now? Message us on WhatsApp").

## WhatsApp strategy

First-class conversion channel, not an afterthought.

| Placement | CTA copy (proposed) |
|---|---|
| Floating button (all pages) | Chat on WhatsApp |
| Header | Get a Quote on WhatsApp |
| Contact page | Discuss Your Event |
| Post-form-submit | Continue on WhatsApp |

Prefilled message template (proposed): "Hi Green Chillyz, I'd like a quote for a [event type] on [date] for [guest count] guests." Number to use: **+91-9090022220 — verify with client before production**, since the audit could not confirm active WhatsApp Business status.

## Contact page

Phone CTA (click-to-call), WhatsApp CTA, email, enquiry form, map/service area (once confirmed), business hours (pending), social links, FAQ link, booking-process summary.

## Booking process (planned flow — not all steps confirmed)

```
1. Customer submits enquiry
2. Green Chillyz reviews requirements
3. Team contacts customer
4. Menu/requirements discussed
5. Quote prepared
6. Quote shared
7. Follow-up
8. Customer confirms
9. Advance/payment process        ← process not confirmed
10. Event planning
11. Catering execution
12. Post-event feedback
```

Steps 1–8 and 12 are reasonably standard for this business type; step 9's mechanics (advance %, payment method) require client confirmation before being described publicly.

## Lead lifecycle (conceptual states)

```
NEW → CONTACTED → REQUIREMENTS_COLLECTED → QUOTE_PREPARED → QUOTE_SENT →
FOLLOW_UP → CONFIRMED → EVENT_COMPLETED
                 (terminal: LOST / CANCELLED, reachable from any non-terminal state)
```

| State | Meaning |
|---|---|
| NEW | Form submitted, not yet actioned |
| CONTACTED | Sales has responded to the enquiry |
| REQUIREMENTS_COLLECTED | Event details confirmed with client |
| QUOTE_PREPARED | Internal quote drafted |
| QUOTE_SENT | Quote shared with client |
| FOLLOW_UP | Awaiting client decision |
| CONFIRMED | Client has booked |
| EVENT_COMPLETED | Event delivered |
| LOST / CANCELLED | No booking resulted |
